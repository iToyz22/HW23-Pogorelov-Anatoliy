import UIKit
import Foundation

var sessionConfig: URLSessionConfiguration = {
    let configuration = URLSessionConfiguration.default
    configuration.allowsCellularAccess = true
    configuration.waitsForConnectivity = true
    configuration.allowsExpensiveNetworkAccess = false
    configuration.timeoutIntervalForRequest = 5.0
    configuration.timeoutIntervalForResource = 10
    return configuration
} ()

let session = URLSession(configuration: sessionConfig)

func getData(url: String?) {
    let url = URL(string: url ?? "Add link")
    guard let url = url else { return }
    
    if  !UIApplication.shared.canOpenURL(url) {
        print("URL incorrect")
    }
    
    session.dataTask(with: url) { data, response, error in
        if error != nil && UIApplication.shared.canOpenURL(url)  {
            print("DataTask error:" + "\(String(describing: error?.localizedDescription ?? ""))" + "\n")
        } else if let response = response as? HTTPURLResponse, response.statusCode == 200 {
            print("Status code: \(response.statusCode)")
            guard let data = data else { return }
            let dataAsString = String(data: data, encoding: .utf8)
            print(dataAsString ?? "")
        }
    }.resume()
}

getData(url: "https://api.thecatapi.com/v1/images/search")


